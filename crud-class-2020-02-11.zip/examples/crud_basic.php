<?php 
/*
CRUD3 EXAMPLE GENERIC PAGE.... CHANGE for customization
*/
// 
$r=dirname(__FILE__);
include("$r/lib/crudClass3.php");
require_once ("$r/lib/irp_commonSQL.php");

if (isset($_GET['id_cliente'])){                                       // CHANGE:  here the PK 
   $_POST = $_GET;   // POST/GET compatible
   }
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo "</head><body>";
// 
echo "<h1> Tavola <b>Clienti</b>: <i>add/edit/delete records</i></h1>";// CHANGE:  page Title

echo "<div class='note' align='center'>
Questa tabella definisce i vari attributi dei <b>clienti</b>.
</div>";                                                               //  CHANGE: intro boz
//--------------------------------------------------  CALLBACKS (if required) 
// callbacks use examples:
/*
//callback for show fields (view)
function crud_get_show($field, $value) {
    $code = $value; // general case
// custom special cases:    
  // change id_user on users.name
   if ($field == 'id_user'){
            $code = sqlValue("SELECT name FROM users WHERE $field = $value");
       }
 // to center value in cell       
   if ($field == 'unit'){
            $code = "<CENTER>$value</CENTER>";
      }
      
  return $code;
}
*/
/*
// callback for input fields (new)
function crud_get_input($field){
  $code = "$field: <input type='text' name='$field' /><br>";  // general case
  // custom special cases    
 // choose id_user from a user.name list
  if ($field == 'id_user'){
       $code = crudClass::make_select($field, "SELECT id_user, name FROM users order by name");   // users.name list 
         } 
// date input field        
  if ($field == 'arrival'){
     $code = "$field: <input type='date' name='$field' /><br>";
  }
  
  return $code;
}
*/
/*
//callback for input fields (edit)
function crud_get_edit($field, $value){
  $code = "$field: <input type='text' name='$field' value='$value' /><br>";  // general case
   // custom special cases    
  // make id_town field readonly
  if ($field == 'id_town'){
         "$field: <input type='text' name='$field' value='$value' readonly /><br>";   
         }    
  // use radio buttons for ENUM:
  if ($field == 'unita_misura'){
         $optionlist= 'Kg,Nr.';
         $code = crudClass::make_radio($field, $optionlist, $value);   // radio 
         }      

   return $code;
} 
*/
/*
//callback add action (view)
function crud_action_hook($record){
 // ad action button 'test_user'
    $code =  "<td><form action='test_user.php'  mode='POST'>";	   
    $code .= "<input type='hidden' name='id_user' value=".$record['id_user'].">";
    $code .= "<input type='submit' name='test_user' value='USER TEST'></form></td>";
    return $code;
}
*/
/*
//callback before create (new)
function    before_create($values){
// $values[2] is three times $values[1]
    $values[2]= 3 *  $values[1] ;
return $values;
*/
/*
function before_update($strings){
// note: strings are like: $strings[2] => "`id_user` = '16'"
// make id_user = 22
  $forced = 22;
  $strings[2]="`id_user` = '$forced'";
return $strings;
*/

// -------------------------------------------------- END CALLBACKS

$crud = new crudClass('clienti','ragione_sociale,piva,cf,indirizzo,cap,id_citta,contatto,telefono,fax,email,destinazione,indirizzo2,cap2,id_citta2,telefono2,commissione,note','id_cliente' );// CHANGE: Initiate the class with table information: table-name, fields, pk

// ================= don't change
if (isset($_POST['submit'])){
    $create_sql = $crud->create();//Fetch INSERT query
    sql($create_sql);
}
if (isset($_POST['update'])){
    $update_sql = $crud->update();//Fetch UPDATE query
   sql($update_sql);
}
if (isset($_POST['delete'])){
    $delete_sql = $crud->delete();//Fetch DELETE query
    sql($delete_sql);
}
// -------------
if (isset($_POST['edit'])){
// edit
    echo "<div class='note' align='right'>";
    echo $crud->renderEditor();//Prepare data edit form
    echo '</div>' ;
    } else {
// or insert    
    echo "<div class='note' align='right'>";
    echo $crud->create_form();//Prepare data entry form
    echo '</div>';
    }
 // table   
 //  =============== don't change ends
echo $crud->renderVertically(' ORDER BY `ragione_sociale`');// CHANGE: for WHERE or ORDER or LIMIT 

echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.html">home</a> </center><br>'; //                    CHANGE: end page menu 
echo "</body></html>";  

?>
