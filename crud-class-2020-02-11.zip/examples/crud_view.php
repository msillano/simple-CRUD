<?php 
/*
CRUD3 EXAMPLE VIEW PAGE.... CHANGE for customization
*/

// 
$r=dirname(__FILE__);
include("$r/lib/crudClass3.php");
require_once ("$r/lib/irp_commonSQL.php");

if (isset($_GET['id_cliente'])){                                       // CHANGE:  here the PK 
   $_POST = $_GET;   // POST/GET compatible
   }
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo "</head><body>";
// 
echo "<h1> Tavola <b>Clienti</b>: <i>add/edit/delete records</i></h1>";// CHANGE:  page Title

echo "<div class='note' align='center'>
Questa tabella definisce i vari attributi dei <b>clienti</b>.
</div>";                                                               //  CHANGE: intro boz
//--------------------------------------------------  CALLBACKS (if required) 
// callbacks use examples: see crud_base
// -------------------------------------------------- END CALLBACKS

$crud = new crudClass('clienti','ragione_sociale,piva,cf,indirizzo,cap,id_citta,contatto,telefono,fax,email,destinazione,indirizzo2,cap2,id_citta2,telefono2,commissione,note','id_cliente' );// CHANGE: Initiate the class with table information: table-name, fields, pk

// ================= now change
if (isset($_POST['submit'])){
// nothing to do
 }
if (isset($_POST['update'])){
 // nothing to do
 }

if (isset($_POST['delete'])){
// records in view can't be deleted. Goto detail page
    movePage(100,'details.php?id_invoice='.$_POST['id_invoice']);   // CHANGE
}
 // -------------
if (isset($_POST['edit'])){
// edit
  // records in view can't be updated. Goto detail page
    movePage(100,'details.php?id_invoice='.$_POST['id_invoice']);   // CHANGE
}
 // table   
 //  =============== change ends
echo $crud->renderVertically(' ORDER BY `pos`');// CHANGE: for WHERE or ORDER or LIMIT 

echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.html">home</a> </center><br>'; //                    CHANGE: end page menu 
echo "</body></html>";  

?>
