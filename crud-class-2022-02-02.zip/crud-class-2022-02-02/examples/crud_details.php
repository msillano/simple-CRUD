<?php 
/*
CRUD3 EXAMPLE DETAIL PAGE.... CHANGE for customization
*/

// 
$r=dirname(__FILE__);
include("$r/lib/crudClass3.php");
require_once ("$r/lib/irp_commonSQL.php");

if (isset($_GET['id_cliente'])){                                       // CHANGE:  here the PK 
   $_POST = $_GET;   // POST/GET compatible
   }
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo "</head><body>";
// 
echo "<h1> table <b>detail</b>: <i>add/edit/delete records</i></h1>";// CHANGE:  page Title

echo "<div class='note' align='center'>
This table presents <b>datails</b> for an envoice.
</div>";                                                               //  CHANGE: intro box
//--------------------------------------------------  CALLBACKS  
// callback for input fields (new)
 function crud_get_input($field){
   $code = "$field: <input type='text' name='$field' /><br>";  
   if ($field == 'id_invoice'){
     if (isset($_POST['id_invoice'])){
      $code = "$field: <input type='text' name='$field' value='".$_POST['id_invoice']."' readonly /><br>"; 
       }
     }
 return $code;
}

//callback for input fields (edit)
function crud_get_edit($field, $value){
  $code = "$field: <input type='text' name='$field' value='$value' /><br>";  // general case
   // custom special cases     
 if ($field == 'id_invoice'){
   $code = "$field: <input type='text' name='$field' value='$value' readonly /><br>";  
   }         
 return $code;
}

// -------------------------------------------------- END CALLBACKS

$crud = new crudClass('details','id_invoice,pos,description,price','id_detail' );// CHANGE: Initiate the class with table information: table-name, fields, pk

// ================= don't change
if (isset($_POST['submit'])){
    $create_sql = $crud->create();//Fetch INSERT query
    sql($create_sql);
}
if (isset($_POST['update'])){
    $update_sql = $crud->update();//Fetch UPDATE query
   sql($update_sql);
}
if (isset($_POST['delete'])){
    $delete_sql = $crud->delete();//Fetch DELETE query
    sql($delete_sql);
}
// -------------
if (isset($_POST['edit'])){
// edit
    echo "<div class='note' align='right'>";
    echo $crud->renderEditor();//Prepare data edit form
    echo '</div>' ;
    } else {
// or insert    
    echo "<div class='note' align='right'>";
    echo $crud->create_form();//Prepare data entry form
    echo '</div>';
    }
 // table   
 //  =============== don't change ends
 if (isset($_POST['id_invoice'])){       // if becomes from master page  CHANGE:
    echo $crud->renderVertically(' WHERE id_invoice = '.$_POST['id_invoice']);// DETAIL: limit records to id_invoice 
    } else
    echo $crud->renderVertically('');   // else show all
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.html">home</a> </center><br>'; //                    CHANGE: end page menu 
echo "</body></html>";  

?>
