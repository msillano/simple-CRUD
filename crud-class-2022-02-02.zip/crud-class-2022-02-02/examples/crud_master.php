<?php 
/*
CRUD3 EXAMPLE MASTER PAGE.... CHANGE for customization
*/
// 
$r=dirname(__FILE__);
include("$r/lib/crudClass3.php");
require_once ("$r/lib/irp_commonSQL.php");

if (isset($_GET['id_cliente'])){                                       // CHANGE:  here the PK 
   $_POST = $_GET;   // POST/GET compatible
   }
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo "</head><body>";
// 
echo "<h1> Tavola <b>Clienti</b>: <i>add/edit/delete records</i></h1>";// CHANGE:  page Title

echo "<div class='note' align='center'>
Questa tabella definisce i vari attributi dei <b>clienti</b>.
</div>";                                                               //  CHANGE: intro boz
//--------------------------------------------------  CALLBACKS (if required) 
// callbacks use examples: see crud_base

// MASTER: add action SHOW DETAILS (id_invoice is the pk/fk), goto: details.php?id_invoice=xxxx
function crud_action_hook($record){
 // add action button 'VIEW DETAILS'  CHANGE:
    $code =  "<td><form action='details.php'  mode='POST'>";	   
    $code .= "<input type='hidden' name='id_invoice' value=".$record['id_invoice'].">";
    $code .= "<input type='submit'  value='VIEW DETAILS'></form></td>";
    return $code;
}

// -------------------------------------------------- END CALLBACKS

$crud = new crudClass('invoice','date,id_client,address','id_invoice' );// CHANGE: Initiate the class with table information: name, fields, pk

// ================= don't change
if (isset($_POST['submit'])){
    $create_sql = $crud->create();//Fetch INSERT query
    sql($create_sql);
}
if (isset($_POST['update'])){
    $update_sql = $crud->update();//Fetch UPDATE query
   sql($update_sql);
}
if (isset($_POST['delete'])){
    $delete_sql = $crud->delete();//Fetch DELETE query
    sql($delete_sql);
}
// -------------
if (isset($_POST['edit'])){
// edit
    echo "<div class='note' align='right'>";
    echo $crud->renderEditor();//Prepare data edit form
    echo '</div>' ;
    } else {
// or insert    
    echo "<div class='note' align='right'>";
    echo $crud->create_form();//Prepare data entry form
    echo '</div>';
    }
 // table   
 //  =============== don't change ends
echo $crud->renderVertically(' ORDER BY `ragione_sociale`');// CHANGE: for WHERE or ORDER or LIMIT 

echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.html">home</a> </center><br>'; //                    CHANGE: end page menu 
echo "</body></html>";  

?>
