<?php	
// TODO: update
$dbServer='localhost';	$dbUsername='root';	$dbPassword='';	$dbDatabase='remotesdb';
//
?>